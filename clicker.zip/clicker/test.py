from time import sleep
import pyautogui, cv2

button6fail = pyautogui.locateOnScreen('item.bmp',region=(1500, 290, 400, 350), grayscale=True, confidence=0.9) #Ищем итем
print(button6fail)